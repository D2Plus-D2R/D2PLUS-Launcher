D2PLUS Alpha V1.1 Accursed practice characters

Four separate level-100 offline characters. Each has a Horadric Cube, 8 of every Elder Gem (56 total), 16 Ritual Sigils and assorted uniques. All difficulties and waypoints are unlocked. No existing character or shared stash is included or modified.

Install only with Alpha V1.1. Copy the .d2s files into your D2PLUS mod save folder while D2R is closed. Use a new name rather than overwriting an existing character.

One of each seven Elder Gems makes a sigil. Put one eligible unique and one sigil in the Cube, then transmute twice. The first press primes the ritual; the second resolves it. 25% produces a random rare of the same base; 75% adds one or two boons. Successful items show Accursed in violet and cannot be attempted again.

These files passed item/save round-trip validation. In-game ritual testing is still required.
